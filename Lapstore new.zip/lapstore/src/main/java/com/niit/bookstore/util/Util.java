package com.niit.bookstore.util;

public class Util {


		public static String removeComma(String name)
		{
			return name.replace(",", "");
		}
	}



